package categories_realz;

public interface MealCategory {
    String meal();
}
