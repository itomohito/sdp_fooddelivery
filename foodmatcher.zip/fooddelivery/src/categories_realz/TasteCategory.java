package categories_realz;

public interface TasteCategory {
    String taste();
}
