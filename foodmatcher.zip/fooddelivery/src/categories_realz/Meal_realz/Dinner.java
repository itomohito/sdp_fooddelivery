package categories_realz.Meal_realz;

import categories_realz.MealCategory;

public class Dinner implements MealCategory {
    @Override
    public String meal() {return " Better to have for your dinner ";}
}
