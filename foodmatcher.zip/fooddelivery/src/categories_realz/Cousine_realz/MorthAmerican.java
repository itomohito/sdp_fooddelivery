package categories_realz.Cousine_realz;

import categories_realz.CousineCategory;

public class MorthAmerican implements CousineCategory {
    @Override
    public String cousine() {return " It is from NorthAmerican cousine"; }
}
