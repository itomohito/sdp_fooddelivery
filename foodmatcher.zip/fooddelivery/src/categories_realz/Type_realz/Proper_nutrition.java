package categories_realz.Type_realz;

import categories_realz.TypeCategory;

public class Proper_nutrition implements TypeCategory {
    @Override
    public String type() {return "It is a proper nutrition type food";};
}
