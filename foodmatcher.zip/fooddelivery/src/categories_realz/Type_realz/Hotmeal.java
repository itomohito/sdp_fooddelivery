package categories_realz.Type_realz;

import categories_realz.TypeCategory;

public class Hotmeal implements TypeCategory {
    @Override
    public String type() {return "It is a hot meal";};
}
