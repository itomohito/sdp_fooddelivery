package categories_realz;

public interface CousineCategory {
    String cousine();
}
