package categories_realz;

public interface TypeCategory {
    String type();
}
