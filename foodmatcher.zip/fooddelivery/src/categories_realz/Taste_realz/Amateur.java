package categories_realz.Taste_realz;

import categories_realz.TasteCategory;

public class Amateur implements TasteCategory{
    @Override
    public String taste() {return "It has mostly for an amateur taste, Btter watch out";}
}
