package categories_realz.Taste_realz;

import categories_realz.TasteCategory;

public class Spicy implements TasteCategory {
    @Override
    public String taste() {return "It has mostly spicy taste";}
}
