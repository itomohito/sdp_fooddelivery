package categories_realz.Taste_realz;

import categories_realz.TasteCategory;

public class Sour implements TasteCategory {
    @Override
    public String taste() {return "It has mostly sour";}
}
